import org.jfree.ui.RefineryUtilities;

public class Main {
    public static void main(String[] args) {
       /* PieChart demo = new PieChart("Comparison", "Which operating system are you using?");
        demo.pack();
        demo.setVisible(true);*/

       /* final LineChart demo2 = new LineChart("Line Chart Demo 6");
        demo2.pack();
        RefineryUtilities.centerFrameOnScreen(demo2);
        demo2.setVisible(true);*/

        String str = "43;43;44;42";
        System.out.println(str.split("42").length);
//        System.out.println(str.split("42")[0]);
//        System.out.println(str.split("42")[1]);
        //System.out.println(str.split("42")[2]);
        //System.out.println(str.endsWith("42"));
    }
} 